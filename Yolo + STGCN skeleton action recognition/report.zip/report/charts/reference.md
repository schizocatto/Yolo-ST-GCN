# Chart Reference

Tổng quan ý nghĩa từng biểu đồ được trích xuất từ hai notebook.

---

## Thư mục: `stgcn_notebook/`
*(Notebook: `stgcn_notebook_with_viz-2.ipynb` — Huấn luyện ST-GCN trên Penn Action Dataset với Ground Truth keypoints)*

| Tên file | Ý nghĩa |
|---|---|
| `action_class_distribution.png` | Bar chart phân phối **toàn bộ 15 lớp hành động** trong Penn Action Dataset (2326 video). Cho thấy sự mất cân bằng dữ liệu giữa các class. |
| `data_stats_and_length_distribution.png` | Hai biểu đồ: (trái) số lượng video theo từng lớp trong nhóm **8 bài tập** được chọn (1163 video); (phải) phân phối độ dài video thô trước khi temporal alignment (min=18, max=663, mean≈83 frames). |
| `sample_video_frames.png` | Lưới ảnh minh họa một số frames thô từ một video ngẫu nhiên trong dataset. |
| `gt_skeleton_overlay.png` | Frame video với **khung xương Ground Truth** (13 joints từ file `.mat`) vẽ đè lên — minh họa chất lượng annotation gốc của Penn Action. |
| `sample_skeleton_gt.png` | Khung xương mẫu dạng đồ thị (stick figure) từ Ground Truth keypoints, hiển thị 14 nodes (13 joints + 1 virtual center). |
| `graph_skeleton_partitions.png` | Đồ thị khung xương 14 nodes tô màu theo **3 loại partition** của ST-GCN: self-loop (xanh lá), centripetal — hướng về trung tâm (cam), centrifugal — hướng ra ngoài (đỏ). Minh họa cấu trúc đồ thị spatial của mô hình. |
| `adjacency_matrix_heatmaps.png` | Ba heatmap của **ma trận kề A[0], A[1], A[2]** sau chuẩn hóa — tương ứng với 3 partition: self-loop, centripetal, centrifugal. Kích thước mỗi ma trận: 14×14. |
| `model_architecture_table.png` | Bảng mô tả **kiến trúc ST-GCN**: các layer block, số channels (64→64→128→128→256→256), kích thước tensor output theo từng tầng, và tổng số tham số. |
| `training_curves.png` | Ba đường cong huấn luyện qua **80 epochs**: (trái) Train/Val Loss; (giữa) Train/Val Accuracy; (phải) Val Macro F1. Best val accuracy ≈ **99.14%** (epoch 45), best F1 ≈ **0.9890**. |
| `confusion_matrix_gt.png` | **Confusion Matrix** trên tập val (233 videos) khi dùng Ground Truth keypoints. Accuracy tổng thể: **98%**. Hầu hết class đạt F1 ≥ 0.97. |
| `per_class_f1_gt.png` | Bar chart **F1-score theo từng class** trên val set với GT keypoints. Các class như `jumping_jacks`, `pullup` đạt F1 = 1.00; thấp nhất là `bench_press` (0.98). |

---

## Thư mục: `yolo_stgcn_notebook/`
*(Notebook: `yolo_stgcn_inference_progress_bar_run_completed.ipynb` — Pipeline đầu cuối YOLOv8-pose + ST-GCN)*

| Tên file | Ý nghĩa |
|---|---|
| `yolo_skeleton_demo.png` | Demo pipeline trên 1 video: (trái) frame với **khung xương YOLO** vẽ đè (17 COCO → 13 Penn → 14 nodes, điểm vàng = virtual center); (phải) **confidence bar chart** của ST-GCN cho từng class. Video demo: `0341`, GT = `bench_press`, Pred = `bench_press` ✓. |
| `yolo_keypoint_quality.png` | Bar chart **sai số keypoint YOLO** so với Ground Truth, chuẩn hóa theo chiều cao người, trên 1158 video. Overall mean error = **3.37** (đơn vị: tỷ lệ chiều cao). Lỗi cao nhất ở `l_ankle`/`r_ankle` (~4.88), thấp nhất ở `head` (~2.70). Màu: xanh < 0.10 (tốt), cam 0.10–0.20 (trung bình), đỏ > 0.20 (kém). |
| `pipeline_confusion_matrix.png` | **Confusion Matrix** của pipeline YOLO + ST-GCN trên 233 videos val set. Accuracy = **73.82%**, Macro F1 = **72.39%**. Tệ nhất: `bench_press` (F1=0.38, chỉ recall 25%); tốt nhất: `jumping_jacks` (F1=0.94), `pullup` (F1=0.93). |

---

## Tóm tắt so sánh

| Metric | ST-GCN + GT Keypoints | YOLO + ST-GCN Pipeline |
|---|---|---|
| Accuracy | **98.28%** | 73.82% |
| Macro F1 | **0.9814** | 0.7239 |
| Nguồn keypoints | Ground Truth `.mat` | YOLOv8n-pose (auto) |

Khoảng cách ~24% accuracy phản ánh sai số lớn của YOLO keypoints (mean normalized error = 3.37) — đặc biệt ở các khớp chi dưới và vai — so với Ground Truth của Penn Action Dataset.
